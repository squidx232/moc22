// Setup script for the project
console.log("Setup completed successfully");
