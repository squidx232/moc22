import { defineApp } from "convex/server";

const app = defineApp();
export default app;
